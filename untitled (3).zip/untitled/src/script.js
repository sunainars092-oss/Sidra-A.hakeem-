// Button JavaScript
let button = document.getElementById("btn");

button.addEventListener("click", function () {
  alert("Button Clicked!");
});